# Emigrant City

Dataset from NYPL’s [NYC Space/Time Directory](http://spacetime.nypl.org).

- [Download this dataset as a ZIP file](http://s3.amazonaws.com/spacetime-nypl-org/emigrant-city/emigrant-city.zip)
- [Data Package](http://s3.amazonaws.com/spacetime-nypl-org/emigrant-city/datapackage.json)
- [View dataset on homepage of NYC Space/Time Directory](http://spacetime.nypl.org/#data-emigrant-city)

## Details

<table>
<tbody>
<tr><td>ID</td><td><code>emigrant-city</code></td></tr>
<tr><td>Title</td><td>Emigrant City</td></tr>
<tr><td>Description</td><td>Crowdsourced transcription of documents from the Emigrant Bank</td></tr>
<tr><td>License</td><td>CC0</td></tr>
<tr><td>Homepage</td><td><a href="http://emigrantcity.nypl.org">http://emigrantcity.nypl.org</a></td></tr>
<tr><td>Sources</td><td><a href="http://emigrantcity.nypl.org/data/latest">Compressed archive of all transcribed documents</a></td></tr>
<tr><td>Contributors</td><td>Bert Spaan, Emigrant City contributors</td></tr>
<tr><td>ETL module</td><td><a href="https://github.com/nypl-spacetime/etl-emigrant-city">https://github.com/nypl-spacetime/etl-emigrant-city</a></td></tr>
<tr><td>Download</td><td><a href="http://s3.amazonaws.com/spacetime-nypl-org/datasets/emigrant-city/emigrant-city.zip">ZIP file</a></td></tr>
</tbody>
</table>
